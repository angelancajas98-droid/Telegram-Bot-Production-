import test from 'node:test';import assert from 'node:assert/strict';
function parseCommand(text){return text.trim().split(/\s+/)[0].toLowerCase().split('@')[0];}
test('command parser strips bot username',()=>assert.equal(parseCommand('/start@TeamMarySyBot hello'),'/start'));
test('command parser handles whitespace',()=>assert.equal(parseCommand('  /panel  '),'/panel'));
test('webhook secret mismatch is rejected by length',()=>assert.notEqual('abc'.length,'abcd'.length));
test('feature callback format is deterministic',()=>assert.equal('panel:support'.split(':')[0],'panel'));
