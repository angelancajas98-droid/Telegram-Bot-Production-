import type {Env} from '../telegram/types';
import {State} from '../state/kv';
import {getDueJobs,saveJob} from '../state/jobs';
import {telegram} from '../telegram/client';
import {getOpenTicketForChat,saveTicket} from '../state/tickets';
import {claimJob,completeJob,releaseJob} from '../platform/coordination';

export async function handleCron(env:Env){
  const state=new State(env.STATE);const bot=telegram(env);
  for(const job of await getDueJobs(state)){
    const claimed=await claimJob(env,job.id,120_000);if(!claimed.claimed||claimed.completed)continue;
    try{
      if(job.type==='sendMessage'||job.type==='broadcast') await bot.sendMessage(Number(job.payload.chatId),String(job.payload.text));
      if(job.type==='closeTicket'){const t=await getOpenTicketForChat(state,Number(job.payload.chatId));if(t){t.status='closed';t.lastActivity=Date.now();await saveTicket(state,t);}}
      job.enabled=false;job.lockedUntil=undefined;job.lastError=undefined;await saveJob(state,job);await completeJob(claimed.stub,claimed.owner);
    }catch(error){
      job.attempts=(job.attempts??0)+1;job.runAt=Date.now()+Math.min(3_600_000,60_000*Math.pow(2,Math.min(job.attempts,5)));job.lockedUntil=undefined;job.lastError=error instanceof Error?error.message:'unknown error';await saveJob(state,job);await releaseJob(claimed.stub,claimed.owner);
    }
  }
}
