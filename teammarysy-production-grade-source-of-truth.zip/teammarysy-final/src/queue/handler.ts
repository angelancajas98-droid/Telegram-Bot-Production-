import type {Env,QueueTask} from '../telegram/types';
import {telegram} from '../telegram/client';
import {claimIdempotencyKey,completeUpdate,abandonUpdate} from '../platform/coordination';

export async function handleQueue(batch:MessageBatch<QueueTask>,env:Env){
  const bot=telegram(env);
  for(const message of batch.messages){
    let guard:Awaited<ReturnType<typeof claimIdempotencyKey>>|undefined;
    try{
      const task=message.body;
      guard=await claimIdempotencyKey(env,`queue:${task.idempotencyKey}`);
      if(guard.action==='duplicate'){message.ack();continue;}
      if(task.type==='telegram.sendMessage') await bot.sendMessage(Number(task.payload.chatId),String(task.payload.text));
      else if(task.type==='telegram.sendPhoto') await bot.sendPhoto(Number(task.payload.chatId),String(task.payload.photo),task.payload.caption?String(task.payload.caption):undefined);
      await completeUpdate(guard.stub,guard.token);
      message.ack();
    }catch(error){
      if(guard?.token) await abandonUpdate(guard.stub,guard.token).catch(()=>{});
      console.error(JSON.stringify({event:'queue_error',message_id:message.id,error:error instanceof Error?error.message:'unknown'}));
      message.retry();
    }
  }
}
