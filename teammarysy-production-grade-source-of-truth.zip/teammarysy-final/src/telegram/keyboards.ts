import type {Config} from '../config/config';
import type {InlineKeyboardMarkup} from './types';
export function startKeyboard(c:Config):InlineKeyboardMarkup { return {inline_keyboard:[
  [{text:'📱 Contact for Support',callback_data:'start:support'}],
  [{text:'💵 Register now',...(c.registerUrl?{url:c.registerUrl}:{callback_data:'start:register'})}],
  [{text:'🌐 Official Telegram ↗',...(c.officialTelegramUrl?{url:c.officialTelegramUrl}:{callback_data:'start:telegram'})}],
  [{text:'💰 Exclusive Offers',...(c.offersUrl?{url:c.offersUrl}:{callback_data:'start:offers'})}],
  [{text:'📱 Download App',...(c.downloadAppUrl?{url:c.downloadAppUrl}:{callback_data:'start:app'})}]
]}; }
export function panelKeyboard(c:Config):InlineKeyboardMarkup { const names=[...c.features];const rows=names.map((f,i)=>({f,i})).reduce((rows,item)=>{const row=Math.floor(item.i/2);(rows[row]??=[]).push({text:item.f[0].toUpperCase()+item.f.slice(1),callback_data:`panel:${item.f}`});return rows;},[] as Array<Array<{text:string;callback_data:string}>>);rows.push([{text:'⬅️ Back',callback_data:'start:home'}]);return {inline_keyboard:rows}; }
export const backKeyboard:InlineKeyboardMarkup={inline_keyboard:[[{text:'⬅️ Back',callback_data:'panel:home'}],[{text:'✖️ Cancel',callback_data:'cancel'}]]};
