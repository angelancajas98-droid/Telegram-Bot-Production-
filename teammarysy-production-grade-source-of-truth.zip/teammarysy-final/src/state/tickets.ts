import {State} from './kv';
export interface Ticket {id:string;chatId:number;userId:number;status:'open'|'closed';ownerId?:number;lastActivity:number;createdAt:number;}
export async function saveTicket(s:State,t:Ticket){await s.put(`ticket:${t.id}`,t);await s.put(`ticket-by-chat:${t.chatId}`,t.id);}
export function getTicket(s:State,id:string){return s.get<Ticket>(`ticket:${id}`);}
export async function getOpenTicketForChat(s:State,chatId:number){const id=await s.get<string>(`ticket-by-chat:${chatId}`);if(!id)return null;const t=await getTicket(s,id);return t?.status==='open'?t:null;}
