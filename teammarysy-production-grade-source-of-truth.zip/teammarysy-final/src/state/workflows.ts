import {State} from './kv';
export interface Workflow { id:string; userId:number; chatId:number; step:string; data:Record<string,unknown>; expiresAt:number; }
export async function saveWorkflow(s:State,w:Workflow){const ttl=Math.max(1,Math.ceil((w.expiresAt-Date.now())/1000));await s.put(`workflow:${w.id}`,w,ttl);}
export async function getWorkflow(s:State,id:string,userId:number){const w=await s.get<Workflow>(`workflow:${id}`);if(!w||w.userId!==userId||w.expiresAt<=Date.now()){if(w)await s.delete(`workflow:${id}`);return null;}return w;}
